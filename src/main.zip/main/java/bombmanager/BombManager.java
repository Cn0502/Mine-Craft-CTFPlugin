package bombmanager;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import lobbymanager.RoundManager;

import java.util.Set;
import java.util.stream.Collectors;

public class BombManager implements Listener {

    private final Plugin plugin;
    private final RoundManager roundManager;

    private boolean bombPlanted = false;
    private boolean bombDefused = false;
    private Location bombLocation = null;
    private int bombExplosionTask = -1;

    public BombManager(Plugin plugin, RoundManager roundManager) {
        this.plugin = plugin;
        this.roundManager = roundManager;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        Location loc = player.getLocation();

        if (!bombPlanted && item != null && item.getType() == Material.TNT && item.hasItemMeta()) {
            String displayName = ChatColor.stripColor(item.getItemMeta().getDisplayName());
            if ("Bomb".equals(displayName)) {
                if (!canPlaceBombHere(loc)) {
                    event.setCancelled(true);
                    loc.getBlock().setType(Material.AIR);
                    player.sendMessage(ChatColor.RED + "You must be in a bomb site to plant the bomb!");
                    return;
                }

                player.sendMessage(ChatColor.YELLOW + "Planting bomb... Hold still for 3.2 seconds.");
                new BukkitRunnable() {
                    int timeLeft = 64;

                    @Override
                    public void run() {
                        if (!player.isOnline() || !canPlaceBombHere(player.getLocation()) || player.getLocation().distance(loc) > 1.5) {
                            player.sendMessage(ChatColor.RED + "Bomb planting interrupted.");
                            cancel();
                            return;
                        }

                        if (--timeLeft <= 0) {
                            bombPlanted = true;
                            bombDefused = false;
                            bombLocation = loc.getBlock().getLocation();
                            player.getInventory().removeItem(item);
                            bombLocation.getBlock().setType(Material.TNT);
                            player.getWorld().playSound(loc, Sound.BLOCK_ANVIL_PLACE, 1.0f, 1.0f);
                            Bukkit.broadcastMessage(ChatColor.RED + "[CTF] Bomb has been planted!");

                            roundManager.onBombPlanted();

                            bombExplosionTask = Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, () -> {
                                if (!bombDefused && bombLocation != null) {
                                    bombLocation.getWorld().createExplosion(bombLocation, 4f, false, false);
                                    bombLocation.getBlock().setType(Material.AIR);
                                    Bukkit.broadcastMessage(ChatColor.DARK_RED + "[CTF] The bomb has exploded!");
                                    roundManager.onBombExploded();
                                    bombPlanted = false;
                                    bombLocation = null;
                                    bombExplosionTask = -1;
                                }
                            }, 40 * 20L);
                            cancel();
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
        }

        if (bombPlanted && bombLocation != null && loc.getBlock().getLocation().equals(bombLocation)) {
            int defuseTime = hasDefuseKit(player) ? 5 : 10;
            startDefuse(player, defuseTime);
        }
    }

    private void startDefuse(Player player, int seconds) {
        Bukkit.broadcastMessage(ChatColor.YELLOW + "[CTF] " + player.getName() + " is defusing the bomb...");

        new BukkitRunnable() {
            int timeLeft = seconds;

            @Override
            public void run() {
                if (!player.isOnline() || !player.getLocation().getBlock().getLocation().equals(bombLocation)) {
                    player.sendMessage(ChatColor.RED + "Defuse canceled.");
                    cancel();
                    return;
                }

                if (timeLeft-- <= 0) {
                    if (bombExplosionTask != -1) {
                        Bukkit.getScheduler().cancelTask(bombExplosionTask);
                        bombExplosionTask = -1;
                    }

                    player.sendMessage(ChatColor.GREEN + "You defused the bomb!");
                    Bukkit.broadcastMessage(ChatColor.GREEN + "[CTF] Bomb has been defused!");
                    bombLocation.getBlock().setType(Material.AIR);
                    bombDefused = true;
                    bombPlanted = false;
                    bombLocation = null;
                    roundManager.onBombDefused();
                    cancel();
                } else {
                    player.sendTitle(ChatColor.YELLOW + "Defusing...", ChatColor.GRAY + String.valueOf(timeLeft) + "s left", 0, 20, 0);
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private boolean hasDefuseKit(Player player) {
        for (ItemStack item : player.getInventory()) {
            if (item != null && item.getType() == Material.SHEARS && item.hasItemMeta()) {
                ItemMeta meta = item.getItemMeta();
                if (meta.hasDisplayName() && ChatColor.stripColor(meta.getDisplayName()).equalsIgnoreCase("Defuse Kit")) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean canPlaceBombHere(Location location) {
        World adaptedWorld = BukkitAdapter.adapt(location.getWorld());
        RegionManager regionManager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(adaptedWorld);
        if (regionManager == null) return false;

        BlockVector3 vector = BukkitAdapter.asBlockVector(location);
        ApplicableRegionSet regions = regionManager.getApplicableRegions(vector);
        Set<String> regionIds = regions.getRegions().stream()
                .map(ProtectedRegion::getId)
                .collect(Collectors.toSet());

        if (regionIds.contains("rust_map")) {
            return regionIds.contains("bombsite_a") || regionIds.contains("bombsite_b");
        }

        return regionIds.contains("bombsite_a") || regionIds.contains("bombsite_b");
    }

    public void clearBombSite() {
        if (bombLocation != null) {
            bombLocation.getBlock().setType(Material.AIR);
            bombLocation = null;
            bombPlanted = false;
            bombDefused = false;
            bombExplosionTask = -1;
        }
    }

    public boolean isBombDefused() {
        return bombDefused;
    }

    public boolean isBombPlanted() {
        return bombPlanted;
    }
}
