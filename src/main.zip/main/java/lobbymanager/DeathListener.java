package lobbymanager;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class DeathListener implements Listener {

    private final RoundManager roundManager;

    public DeathListener(RoundManager roundManager) {
        this.roundManager = roundManager;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        roundManager.onPlayerDeath(player);
    }
}
