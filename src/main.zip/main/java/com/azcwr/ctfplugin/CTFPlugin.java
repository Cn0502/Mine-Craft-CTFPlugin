package com.azcwr.ctfplugin;

import lobbymanager.LobbyManager;
import lobbymanager.PlayerJoinListener;
import lobbymanager.DeathListener;
import lobbymanager.RoundManager;
import bombmanager.BombManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class CTFPlugin extends JavaPlugin {

    private LobbyManager lobbyManager;
    private RoundManager roundManager;
    private BombManager bombManager;

    @Override
    public void onEnable() {
        getLogger().info("CTFPlugin enabled.");

        this.lobbyManager = new LobbyManager();
        this.roundManager = new RoundManager(this, lobbyManager);
        this.bombManager = new BombManager(this, roundManager);

        getServer().getPluginManager().registerEvents(new PlayerJoinListener(lobbyManager), this);
        getServer().getPluginManager().registerEvents(new DeathListener(roundManager), this);
        getServer().getPluginManager().registerEvents(bombManager, this);
    }

    @Override
    public void onDisable() {
        getLogger().info("CTFPlugin disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can run this command.");
            return true;
        }

        switch (command.getName().toLowerCase()) {
            case "restartctf":
                roundManager.resetMatch();
                Bukkit.broadcastMessage(ChatColor.YELLOW + "[CTF] Game has been reset.");
                return true;

            case "jointeam":
                if (args.length != 1) {
                    player.sendMessage(ChatColor.RED + "Usage: /jointeam <red|blue>");
                    return true;
                }

                String team = args[0].toLowerCase();
                if (team.equals("red")) {
                    lobbyManager.forceAddToRed(player);
                    player.sendMessage(ChatColor.RED + "You joined Red Team (forced).");
                } else if (team.equals("blue")) {
                    lobbyManager.forceAddToBlue(player);
                    player.sendMessage(ChatColor.BLUE + "You joined Blue Team (forced).");
                } else {
                    player.sendMessage(ChatColor.RED + "Invalid team. Use red or blue.");
                }
                return true;

            default:
                return false;
        }
    }
}
